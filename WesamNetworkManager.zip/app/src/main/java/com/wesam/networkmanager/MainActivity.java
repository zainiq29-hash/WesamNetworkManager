package com.wesam.networkmanager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText hostInput, portInput, userInput, passInput;
    private TextView status, routerInfo, trafficInfo, devicesInfo, diagnostics;
    private Button connectButton, refreshButton;
    private RouterOsApi api;
    private boolean connected = false;
    private String latestReport = "لا يوجد تقرير بعد.";
    private final int bg = Color.rgb(14, 22, 31);
    private final int panel = Color.rgb(25, 37, 49);
    private final int green = Color.rgb(42, 190, 126);
    private final int white = Color.rgb(238, 244, 248);
    private final int muted = Color.rgb(164, 180, 193);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView title = text("WESAM NETWORK MANAGER", 22, white, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());
        TextView subtitle = text("MIKROTIK CONTROL CENTER  •  LOCAL", 11, green, true);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap(); subLp.bottomMargin = dp(18);
        root.addView(subtitle, subLp);

        LinearLayout connection = card();
        addSectionTitle(connection, "اتصال الراوتر");
        hostInput = field("عنوان الراوتر", "192.168.88.1");
        portInput = field("منفذ API", "8728");
        userInput = field("اسم المستخدم", "");
        passInput = field("كلمة المرور", "");
        passInput.setInputType(129);
        connection.addView(hostInput, fieldLp());
        connection.addView(portInput, fieldLp());
        connection.addView(userInput, fieldLp());
        connection.addView(passInput, fieldLp());
        TextView warning = text("تنبيه: الاتصال الأولي يستخدم API المحلي غير المشفّر. استخدم حساب قراءة مخصصاً، ولا تفتح المنفذ على الإنترنت.", 12, muted, false);
        warning.setPadding(0, dp(8), 0, dp(8));
        connection.addView(warning, matchWrap());
        connectButton = button("اتصال بالراوتر", green);
        connection.addView(connectButton, buttonLp());
        root.addView(connection, cardLp());

        LinearLayout summary = card();
        addSectionTitle(summary, "حالة الشبكة");
        status = text("غير متصل", 16, muted, true);
        summary.addView(status, matchWrap());
        routerInfo = text("معلومات الراوتر ستظهر بعد الاتصال.", 14, white, false);
        routerInfo.setPadding(0, dp(10), 0, 0);
        summary.addView(routerInfo, matchWrap());
        root.addView(summary, cardLp());

        LinearLayout traffic = card();
        addSectionTitle(traffic, "مراقبة حركة الإنترنت");
        trafficInfo = text("التنزيل: --\nالرفع: --", 16, white, true);
        traffic.addView(trafficInfo, matchWrap());
        root.addView(traffic, cardLp());

        LinearLayout devices = card();
        addSectionTitle(devices, "الأجهزة المسجلة في DHCP");
        devicesInfo = text("لا توجد بيانات بعد.", 13, white, false);
        devices.addView(devicesInfo, matchWrap());
        root.addView(devices, cardLp());

        LinearLayout diag = card();
        addSectionTitle(diag, "التشخيص");
        diagnostics = text("سيظهر ملخص الفحص هنا.", 13, white, false);
        diag.addView(diagnostics, matchWrap());
        refreshButton = button("تحديث الفحص", Color.rgb(48, 117, 190));
        refreshButton.setEnabled(false);
        diag.addView(refreshButton, buttonLp());
        Button shareButton = button("مشاركة تقرير الفحص مع ChatGPT", Color.rgb(74, 88, 105));
        diag.addView(shareButton, buttonLp());
        shareButton.setOnClickListener(v -> shareReport());
        root.addView(diag, cardLp());

        TextView footer = text("نسخة أولية 0.1.0  •  قراءة فقط", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, matchWrap());
        setContentView(scroll);

        connectButton.setOnClickListener(v -> connect());
        refreshButton.setOnClickListener(v -> refresh());
    }

    private void connect() {
        final String host = hostInput.getText().toString().trim();
        final String username = userInput.getText().toString().trim();
        final String password = passInput.getText().toString();
        final int port;
        try { port = Integer.parseInt(portInput.getText().toString().trim()); }
        catch (Exception e) { toast("تحقق من رقم المنفذ"); return; }
        if (host.isEmpty() || username.isEmpty()) { toast("أدخل عنوان الراوتر واسم المستخدم"); return; }
        connectButton.setEnabled(false);
        status.setText("جارٍ الاتصال...");
        worker.execute(() -> {
            RouterOsApi newApi = new RouterOsApi();
            try {
                newApi.connect(host, port, username, password);
                if (api != null) api.close();
                api = newApi;
                connected = true;
                runOnUiThread(() -> {
                    status.setText("متصل بالراوتر  •  " + host);
                    status.setTextColor(green);
                    refreshButton.setEnabled(true);
                    connectButton.setEnabled(true);
                    toast("تم الاتصال بنجاح");
                });
                fetchDashboard();
            } catch (Exception e) {
                newApi.close();
                connected = false;
                runOnUiThread(() -> {
                    status.setText("فشل الاتصال: " + safe(e.getMessage()));
                    status.setTextColor(Color.rgb(255, 115, 105));
                    connectButton.setEnabled(true);
                    refreshButton.setEnabled(false);
                });
            }
        });
    }

    private void refresh() {
        if (!connected || api == null) return;
        refreshButton.setEnabled(false);
        diagnostics.setText("جارٍ تحديث معلومات الشبكة...");
        worker.execute(() -> {
            try { fetchDashboard(); }
            catch (Exception e) {
                runOnUiThread(() -> diagnostics.setText("تعذر إكمال الفحص: " + safe(e.getMessage())));
            }
            finally { runOnUiThread(() -> refreshButton.setEnabled(connected)); }
        });
    }

    private void fetchDashboard() throws IOException {
        List<Map<String, String>> resources = api.command("/system/resource/print");
        List<Map<String, String>> identity = api.command("/system/identity/print");
        List<Map<String, String>> leases = api.command("/ip/dhcp-server/lease/print", "=.proplist=address,mac-address,host-name,status,dynamic");
        List<Map<String, String>> traffic = api.command("/interface/monitor-traffic", "=interface=ether1", "=once=");
        Map<String, String> r = resources.isEmpty() ? java.util.Collections.emptyMap() : resources.get(0);
        Map<String, String> id = identity.isEmpty() ? java.util.Collections.emptyMap() : identity.get(0);
        Map<String, String> t = traffic.isEmpty() ? java.util.Collections.emptyMap() : traffic.get(0);
        StringBuilder info = new StringBuilder();
        info.append("الاسم: ").append(value(id, "name", "MikroTik")).append('\n');
        info.append("الموديل: RB951Ui-2HnD\n");
        info.append("RouterOS: ").append(value(r, "version", "غير معروف")).append('\n');
        info.append("مدة التشغيل: ").append(value(r, "uptime", "غير معروف")).append('\n');
        info.append("المعالج: ").append(value(r, "cpu-load", "-")).append("%  •  ").append(value(r, "cpu-frequency", "-")).append(" MHz\n");
        info.append("الذاكرة المتاحة: ").append(value(r, "free-memory", "-")).append(" / ").append(value(r, "total-memory", "-")).append('\n');
        String rx = value(t, "rx-bits-per-second", "0");
        String tx = value(t, "tx-bits-per-second", "0");
        StringBuilder deviceText = new StringBuilder();
        int shown = 0;
        for (Map<String, String> lease : leases) {
            if (shown++ >= 40) { deviceText.append("... تم إخفاء بقية السجلات"); break; }
            deviceText.append(value(lease, "address", "-")).append("   ")
                    .append(value(lease, "host-name", "بدون اسم"))
                    .append("   [").append(value(lease, "status", "سجل")).append("]\n");
        }
        if (leases.isEmpty()) deviceText.append("لا توجد سجلات DHCP ظاهرة.");
        String diagnosis = "تم جلب معلومات الراوتر بنجاح.\n" +
                "عدد سجلات DHCP: " + leases.size() + "\n" +
                "ملاحظة: قراءة السرعة لحظية وليست اختبار سرعة اشتراك.\n" +
                "هذه النسخة لا تغيّر إعدادات الراوتر ولا تحظر الأجهزة.";
        latestReport = "Wesam Network Manager - تقرير فحص\n" + info + "\nحركة الإنترنت\nRX: " + formatRate(rx) + "\nTX: " + formatRate(tx) + "\nالأجهزة المسجلة: " + leases.size() + "\n" + diagnosis;
        runOnUiThread(() -> {
            routerInfo.setText(info.toString());
            trafficInfo.setText("التنزيل RX: " + formatRate(rx) + "\nالرفع TX: " + formatRate(tx));
            devicesInfo.setText(deviceText.toString());
            diagnostics.setText(diagnosis);
        });
    }

    private void shareReport() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Wesam Network Manager - تقرير الراوتر");
        send.putExtra(Intent.EXTRA_TEXT, latestReport);
        startActivity(Intent.createChooser(send, "مشاركة تقرير الشبكة"));
    }

    private String formatRate(String raw) {
        try {
            double bps = Double.parseDouble(raw);
            if (bps >= 1_000_000) return String.format(Locale.US, "%.2f Mbps", bps / 1_000_000d);
            if (bps >= 1_000) return String.format(Locale.US, "%.1f Kbps", bps / 1_000d);
            return String.format(Locale.US, "%.0f bps", bps);
        } catch (Exception e) { return raw + " bps"; }
    }

    private String value(Map<String, String> map, String key, String fallback) {
        String v = map.get(key); return v == null || v.isEmpty() ? fallback : v;
    }
    private String safe(String s) { return s == null ? "خطأ غير معروف" : s; }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable d = new GradientDrawable(); d.setColor(panel); d.setCornerRadius(dp(18));
        box.setBackground(d); return box;
    }
    private void addSectionTitle(LinearLayout parent, String value) {
        TextView t = text(value, 17, green, true); t.setPadding(0, 0, 0, dp(12)); parent.addView(t, matchWrap());
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint);
        e.setTextColor(white); e.setHintTextColor(muted); e.setTextSize(14); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(muted));
        return e;
    }
    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(12)); b.setBackground(d);
        return b;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams fieldLp() { LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(5); return p; }
    private LinearLayout.LayoutParams buttonLp() { LinearLayout.LayoutParams p = matchWrap(); p.topMargin = dp(8); return p; }
    private LinearLayout.LayoutParams cardLp() { LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(12); return p; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (api != null) api.close();
        worker.shutdownNow();
    }
}
