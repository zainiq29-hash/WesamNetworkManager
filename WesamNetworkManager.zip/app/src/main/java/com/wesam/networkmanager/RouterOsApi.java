package com.wesam.networkmanager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Minimal RouterOS API client. This first release intentionally exposes read-only commands only. */
final class RouterOsApi implements AutoCloseable {
    private final Socket socket = new Socket();
    private BufferedInputStream in;
    private BufferedOutputStream out;

    void connect(String host, int port, String username, String password) throws IOException {
        socket.connect(new InetSocketAddress(host, port), 5000);
        socket.setSoTimeout(7000);
        in = new BufferedInputStream(socket.getInputStream());
        out = new BufferedOutputStream(socket.getOutputStream());
        List<Map<String, String>> result = command("/login", "=name=" + username, "=password=" + password);
        // RouterOS 6.43+ accepts direct name/password login. Older challenge responses are not accepted here.
        if (result == null) throw new IOException("تعذر تسجيل الدخول إلى الراوتر");
    }

    synchronized List<Map<String, String>> command(String... words) throws IOException {
        for (String word : words) writeWord(word);
        writeWord("");
        out.flush();
        List<Map<String, String>> rows = new ArrayList<>();
        while (true) {
            List<String> sentence = readSentence();
            if (sentence.isEmpty()) continue;
            String type = sentence.get(0);
            if ("!re".equals(type)) {
                Map<String, String> row = new LinkedHashMap<>();
                for (int i = 1; i < sentence.size(); i++) {
                    String w = sentence.get(i);
                    if (w.startsWith("=") && w.length() > 1) {
                        int p = w.indexOf('=', 1);
                        if (p > 1) row.put(w.substring(1, p), w.substring(p + 1));
                    }
                }
                rows.add(row);
            } else if ("!trap".equals(type)) {
                String message = "رفض الراوتر الأمر";
                for (String w : sentence) if (w.startsWith("=message=")) message = w.substring(9);
                throw new IOException(message);
            } else if ("!fatal".equals(type)) {
                throw new IOException("انتهى اتصال API بصورة غير متوقعة");
            } else if ("!done".equals(type)) {
                return rows;
            }
        }
    }

    private void writeWord(String word) throws IOException {
        byte[] b = word.getBytes(StandardCharsets.UTF_8);
        writeLength(b.length);
        out.write(b);
    }

    private void writeLength(int n) throws IOException {
        if (n < 0x80) out.write(n);
        else if (n < 0x4000) { out.write((n >> 8) | 0x80); out.write(n); }
        else if (n < 0x200000) { out.write((n >> 16) | 0xC0); out.write(n >> 8); out.write(n); }
        else if (n < 0x10000000) { out.write((n >> 24) | 0xE0); out.write(n >> 16); out.write(n >> 8); out.write(n); }
        else { out.write(0xF0); out.write(n >> 24); out.write(n >> 16); out.write(n >> 8); out.write(n); }
    }

    private List<String> readSentence() throws IOException {
        List<String> words = new ArrayList<>();
        while (true) {
            int len = readLength();
            if (len == 0) return words;
            byte[] b = new byte[len];
            int off = 0;
            while (off < len) {
                int got = in.read(b, off, len - off);
                if (got < 0) throw new IOException("انقطع الاتصال أثناء قراءة رد الراوتر");
                off += got;
            }
            words.add(new String(b, StandardCharsets.UTF_8));
        }
    }

    private int readLength() throws IOException {
        int c = in.read();
        if (c < 0) throw new IOException("انقطع الاتصال بالراوتر");
        if ((c & 0x80) == 0) return c;
        if ((c & 0xC0) == 0x80) return ((c & ~0xC0) << 8) + readByte();
        if ((c & 0xE0) == 0xC0) return ((c & ~0xE0) << 16) + (readByte() << 8) + readByte();
        if ((c & 0xF0) == 0xE0) return ((c & ~0xF0) << 24) + (readByte() << 16) + (readByte() << 8) + readByte();
        if (c == 0xF0) return (readByte() << 24) + (readByte() << 16) + (readByte() << 8) + readByte();
        throw new IOException("صيغة رد غير معروفة من الراوتر");
    }

    private int readByte() throws IOException {
        int v = in.read();
        if (v < 0) throw new IOException("انقطع الاتصال بالراوتر");
        return v;
    }

    @Override public void close() {
        try { socket.close(); } catch (IOException ignored) { }
    }
}
